export const TermRows=24;
export const TermCols=80;
