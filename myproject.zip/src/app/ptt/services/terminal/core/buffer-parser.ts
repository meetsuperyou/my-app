import {TermBuffer} from "./term-buffer";

const enum ParserState
{
  TEXT,
  ESC,
  CSI, // Control Sequence Introducer: \x1b[
  C1,  // C1 Control Codes: \x1b followed by a single char
}

const ESC = "\x1b";

export class BufferParser
{
  private state: ParserState = ParserState.TEXT;
  private textBuffer: string = "";
  private paramsBuffer: string = "";
  private firstChar = "";

  constructor(private termBuffer: TermBuffer)
  {
  }

  // this.parser.feed(data);
  parseTermBufferData(data: string)
  {
    this.textBuffer = "";
    for (const char of data)
    {
      switch (this.state)
      {
        case ParserState.TEXT:
          this.handleTextState(char);
          break;
        case ParserState.ESC:
          this.handleEscState(char);
          break;
        case ParserState.CSI:
          this.handleCsiState(char);
          break;
        case ParserState.C1:
          this.handleC1State(char);
          break;
      }
    } // end for
    this.flushTextBuffer();// 處理迴圈結束後剩餘的純文字
  }

  private handleCsiState(finalByte: string): void
  {
    // CSI 序列由參數字元 (0-9;?) 和一個結束的命令字元 (A-Z, a-z) 組成
    // if ((ch >= "`" && ch <= "z") || (ch >= "@" && ch <= "Z"))
    // if ((char >= "`" && char <= "z") || (char >= "@" && char <= "Z"))
    if (finalByte >= "@" && finalByte <= "~")
    {
      this.processCsiCommand(finalByte, this.termBuffer);// 處理 switch
      // 無論 processCsiCommand 成功或失敗，都清空 paramsBuffer
      this.state = ParserState.TEXT;
      this.paramsBuffer = "";
    }
    else
    {
      this.paramsBuffer += finalByte; // 累積 esc = \x1b[38;5;27，沒有m，沒有H
    }
  }

  private isNumberStringsOrEmpty(arr: string[])
  {
    return arr.every(el => (el === "" || (/^\d+$/.test(el)))
    );
  }

  private processCsiCommand(finalByte: string, term: TermBuffer): void
  {
    let params1 = this.paramsBuffer.split(";");
    if (!this.isNumberStringsOrEmpty(params1)) // ptt 只處理數字 para
    {
      return; // 外面會清空
    }
    let params: number[] = params1.map(p => parseInt(p, 10) || 0);// array 的 空字串補0
    switch (finalByte)
    {
            // --- 游標移動 ---
      case "A": // 游標上移 n 行（預設 1）。
        // 如果是0,就換成1;  *[A = *[0A = *[1A
        this.termBuffer.moveCursor(term.cursor_x, term.cursor_y - (params[0] ? params[0] : 1));
        break;
      case "B": //游標下移 n 行（預設 1）
        this.termBuffer.moveCursor(term.cursor_x, term.cursor_y + (params[0] ? params[0] : 1));
        break;
      case "C": // 游標右移 n 行（預設 1）。
        this.termBuffer.moveCursor(term.cursor_x + (params[0] ? params[0] : 1), term.cursor_y);
        break;
      case "D": //游標左移 n 行（預設 1）
        this.termBuffer.moveCursor(term.cursor_x - (params[0] ? params[0] : 1), term.cursor_y);
        break;
      case "E":
      case "e": // 游標下移 n 行，並回到行首
        // this.termBuffer.setCursorX(0); 回到行首，下面做
        this.termBuffer.moveCursor(0, term.cursor_y + (params[0] ? params[0] : 1));
        break;
      case "F": // 游標上移 n 行，並回到行首。
        // this.termBuffer.setCursorX(0);
        this.termBuffer.moveCursor(0, term.cursor_y - (params[0] ? params[0] : 1));
        break;
      case "G":
      case "`": // 移動游標到指定的欄位
        this.termBuffer.moveCursor(params[0] > 0 ? params[0] - 1 : 0, term.cursor_y);
        break;
      case "d": // 移動游標到指定的列
        this.termBuffer.moveCursor(term.cursor_x, params[0] > 0 ? params[0] - 1 : 0);
        break;
      case "H": // 移動游標到指定的 (row, col)。
      case "f":
        if (params.length < 2)
        {
          term.moveCursor(0, 0);
        }
        else
        {
          if (params[0] > 0)
            --params[0];
          if (params[1] > 0)
            --params[1];
          term.moveCursor(params[1], params[0]);
        }
        break;
      case "s":// 儲存游標位置。
        this.termBuffer.saveCursorPosition();
        break;
      case "u": // 回復游標位置。
        this.termBuffer.restoreCursorPosition();
        break;

            // --- 擦除與刪除 ---
      case "J": // 清除螢幕（0=光標到末尾, 1=開頭到光標, 2=整個畫面）
        this.termBuffer.eraseScreen(params ? params[0] : 0);
        break;
      case "K": // 清除游標所在行（0=游標到行尾, 1=行首到游標, 2=整行）
        // this.termBuffer.eraseLine(p(0, 0));
        break;
      case "L": // 插入 n 行。
        // this.termBuffer.insertLine(p(0));
        break;
      case "M": // 刪除 n 行。
        // this.termBuffer.deleteLine(p(0));
        break;
      case "P": // 刪除 n 個字元。
        // this.termBuffer.deleteChars(p(0));
        break;
      case "@": // 插入 n 個空白字元。
        // this.termBuffer.insertChars(p(0));
        break;
      case "X": // 清除游標右邊 n 個字元。
        // this.termBuffer.eraseChars(p(0));
        break;

            // --- 捲動 ---
      case "r": // 設定滾動區域（例如只讓中間幾行能捲動）。
        // this.termBuffer.setScrollRegion(p(0, 1) - 1, p(1, 0) - 1);
        break; // p1: top, p2: bottom
      case "S": // 捲動螢幕 n 行（新行加在底部）
        // this.termBuffer.scrollUp(p(0));
        break;
      case "T": //反向捲動 n 行（新行加在頂部）。
        // this.termBuffer.scrollDown(p(0));
        break;

            // --- SGR (圖形渲染) ---
      case "m":
        this.termBuffer.applySgrAttributes(params);
        break;
      default:
        console.warn(`Unsupported CSI command: '${finalByte}' with params: [${params.join(",")}]`);
    }
  }

  private handleTextState(char: string): void
  {
    if (char === ESC)
    {
      this.flushTextBuffer();
      this.state = ParserState.ESC;
    }
    else
    {
      this.textBuffer += char;
    }
  }

  private handleEscState(char: string): void
  {
    if (char === "[")
    { // esc 後面一定是 [，下一個字就是 csi
      this.state = ParserState.CSI;
    }
    else
    {
      // 處理 ESC 後面不是 '[' 的情況，這個字就是 c1
      this.state = ParserState.C1;
      this.handleC1State(char); // 立即處理這個字元
    }
  }

  private handleC1State(char: string): void
  {
    // C1 控制碼的簡易處理
    // vt100 不用 C1
    switch (char)
    {
      case "7":
        this.termBuffer.saveCursorPosition();
        break;
      case "8":
        this.termBuffer.restoreCursorPosition();
        break;
      case "D": // Index
        this.termBuffer.scrollDown(1);
        break;
      case "E": // Next Line
        // this.termBuffer.setCursorX(0);
        this.termBuffer.moveCursor(0, 1);
        break;
      case "M": // Reverse Index
        this.termBuffer.scrollUp(1);
        break;
    }
    // C1 控制碼通常只有一個字元，處理完就回到 TEXT 狀態
    this.state = ParserState.TEXT;
  }

  private flushTextBuffer(): void
  {
    if (this.textBuffer)
    {
      this.termBuffer.putText(this.textBuffer);
      this.textBuffer = "";
    }
  }
}
