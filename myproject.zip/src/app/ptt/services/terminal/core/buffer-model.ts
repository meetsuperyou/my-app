// enum 可以被更改。  const enum 不可以被更改
// 顏色是 css 控制的。 不是 enum.
export enum SgrColor
{
  _30_Black,
  _31_Red,
  _32_Green,
  _33_Yellow,
  _34_Blue,
  _35_Magenta, // 洋紅/紫色
  _36_Cyan, // 青色
  _37_LightGray, //淺灰
  _40_Black,
  _41_Red,
  _42_Green,
  _43_Yellow,
  _44_Blue,
  _45_Magenta, // 洋紅/紫色
  _46_Cyan, // 青色
  _47_LightGray, //淺灰
}

export interface Cell
{
  char: string;
  attrs: SgrAttributes;
}

export interface SgrAttributes
{
  fg: SgrColor;
  bg: SgrColor;
  bright: boolean;
  inverse: boolean;
  blink: boolean;
  underline: boolean;
  isLeadByte: boolean;
}
