import {Cell2, CellAttributes2} from "../../../../temp/gemini-terminal/terminal.model";
import {TermCols, TermRows} from "../terminal-constants";
import {IwebSocket} from "../websocket/I-Ws";
import {Cell, SgrAttributes, SgrColor} from "./buffer-model";

const DEFAULT_ATTRIBUTES: SgrAttributes =
        {
          fg: SgrColor._37_LightGray,
          bg: SgrColor._40_Black,
          bright: false, blink: false, underline: false, inverse: false, isLeadByte: false
        };
const DEFAULT_CELL: Cell = {
  char: " ", attrs: {
    ...DEFAULT_ATTRIBUTES,
  }
};

export class TermBuffer
{
  cols = TermCols;
  rows = TermRows;
  cursor_x = 0;
  cursor_y = 0;
  save_cursor_x = -1;
  save_cursor_y = -1;
  buffer: Cell[][];

  constructor()
  {
    this.buffer = this.initBuffer();
    this.unitTest();
  }

  unitTest()
  {
    // console.log(`see=\n${this.dump()}`);
    this.buffer[0][0].char = "H";
    this.buffer[0][1].char = "i";
    this.dump();
  }

  private createCell(): Cell
  {
    // 每次都回傳新的 Cell
    return {
      char: " ",
      attrs: {...DEFAULT_ATTRIBUTES},
    };
  }

  initBuffer(): Cell[][]
  {
    return Array.from({length: this.rows}, () =>
            Array.from({length: this.cols}, () => this.createCell())
    );
  }

  toJSON(): string
  {
    return JSON.stringify(this.buffer, null, 2);
    // 第二個參數 null, 第三個參數 2 → 美化縮排，方便看
  }

  dump(): void
  {
    const lines = this.buffer.map(row => row.map(cell => cell.char).join(""));
    console.log(lines.join("\n"));
  }

  putText(text: string)
  {
  }

  moveCursor(x: number, y: number)
  {
    if (x >= this.cols)
      x = this.cols - 1;
    if (y >= this.rows)
      y = this.rows - 1;
    if (x < 0)
      x = 0;
    if (y < 0)
      y = 0;
    this.cursor_x = x;
    this.cursor_y = y;
  }

  saveCursorPosition()
  {
    this.save_cursor_x = this.cursor_x;
    this.save_cursor_y = this.cursor_y;
  }

  restoreCursorPosition()
  {
    if (this.save_cursor_x < 0 || this.save_cursor_y < 0)
      return;
    this.cursor_x = this.save_cursor_x;
    this.cursor_y = this.save_cursor_y;
  }

  eraseScreen(p: any)
  {
  }

  eraseLine(p: any)
  {
  }

  insertLine(p: any)
  {
  }

  deleteLine(p: any)
  {
  }

  deleteChars(p: any)
  {
  }

  insertChars(p: any)
  {
  }

  eraseChars(p: any)
  {
  }

  setScrollRegion(number: number, number2: number)
  {
  }

  scrollUp(p: any)
  {
  }

  scrollDown(p: any)
  {
  }

  applySgrAttributes(params: number[])
  {
  }
}
