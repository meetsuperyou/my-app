import {wsConfig} from "../app/ptt/services/terminal/websocket/ws-config";

export const environment = {
  production: true,
  wscofig: wsConfig.production
};
